import AWS from 'aws-sdk';

// Create an instance of the DynamoDB DocumentClient
const dynamodb = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
    const { id } = event; // Get the ID of the person to be deleted

    // Prepare the parameters for the DynamoDB delete operation
    const params = {
        TableName: 'Building', // Specify the table name
        Key: { id } // Specify the key of the item to be deleted
    };

    try {
        // Use the DocumentClient to delete the item from DynamoDB
        await dynamodb.delete(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Person deleted successfully' })
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to delete person from DynamoDB' })
        };
    }
};
