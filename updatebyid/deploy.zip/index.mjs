import AWS from 'aws-sdk';

// Create an instance of the DynamoDB DocumentClient
const dynamodb = new AWS.DynamoDB.DocumentClient();

export const handler = async (event) => {
    const { id, name, surname } = event; // Get the ID, name, and surname of the person to update

    // Prepare the parameters for the DynamoDB update operation
    const params = {
        TableName: 'Building', // Specify the table name
        Key: { id }, // Specify the key of the item to update
        UpdateExpression: 'SET #n = :name, #s = :surname', // Set the attributes to update
        ExpressionAttributeNames: {
            '#n': 'name', // Attribute name for 'name'
            '#s': 'surname' // Attribute name for 'surname'
        },
        ExpressionAttributeValues: {
            ':name': name, // Value for 'name'
            ':surname': surname // Value for 'surname'
        }
    };

    try {
        // Use the DocumentClient to update the item in DynamoDB
        await dynamodb.update(params).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'Person updated successfully' })
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Failed to update person in DynamoDB' })
        };
    }
};
